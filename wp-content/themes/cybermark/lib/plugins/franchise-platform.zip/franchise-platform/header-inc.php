<div class="dashboard-head">
	<div class="container-fluid ">
		<div class="cybermark-header__brand   cybermark-grid__item" id="cybermark_header_brand">
			<a class="cybermark-header__brand-logo" href="https://www.cybermark.com/" target="_blank">
				<img src="<?php echo plugin_dir_url( dirname( __FILE__ ) ) . '/cybermark-platform/Burst.png'; ?>" alt="CyberMark">
			</a>		
		</div>
		<div class="cybermark-header-menu-wrapper ">
    		<div id="cybermark_header_menu" class="cybermark-header-menu ">
		        <ul class="cybermark-menu__nav ">
		            <li class="cybermark-menu__item">
		            	<a href="<?php echo admin_url();?>admin.php?page=lead_tracking" class="cybermark-menu__link">
		            		<span class="cybermark-menu__link-text">Lead Tracking</span>
		            	</a>
		            </li>
		            <li class="cybermark-menu__item">
		            	<a href="<?php echo admin_url();?>admin.php?page=cybermark_support" class="cybermark-menu__link">
		            		<span class="cybermark-menu__link-text">SMART Support</span>
		            	</a>
		            </li>
		            <li class="cybermark-menu__item">
		            	<a href="<?php echo admin_url();?>admin.php?page=cybermark_report" class="cybermark-menu__link">
		            		<span class="cybermark-menu__link-text">CyberMark Reporting</span>
		            	</a>
		            </li>
		        </ul>
    		</div>
		</div>
	</div>
</div>