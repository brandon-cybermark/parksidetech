interface AmeDictionary<T> {
	[mapKey: string] : T;
}