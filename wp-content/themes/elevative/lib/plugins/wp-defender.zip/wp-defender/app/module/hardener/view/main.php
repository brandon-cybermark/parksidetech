<?php do_action('tweaks_footer'); ?>
<div id="defender"></div>