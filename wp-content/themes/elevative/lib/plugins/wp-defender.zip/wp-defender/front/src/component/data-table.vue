<template>
    <slot></slot>
</template>

<script>
    export default {
        name: "data-table",
        props: ['headers',''],
    }
</script>
