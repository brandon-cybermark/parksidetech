<?php
define('AME_WIDGET_EDITOR_DIR', dirname(__FILE__));

require_once AME_WIDGET_EDITOR_DIR . '/ameDashboardWidget.php';
require_once AME_WIDGET_EDITOR_DIR . '/ameStandardWidgetWrapper.php';
require_once AME_WIDGET_EDITOR_DIR . '/ameCustomHtmlWidget.php';
require_once AME_WIDGET_EDITOR_DIR . '/ameCustomRssWidget.php';
require_once AME_WIDGET_EDITOR_DIR . '/ameWidgetCollection.php';
require_once AME_WIDGET_EDITOR_DIR . '/ameWidgetEditor.php';
