<template>
    <div class="wd-overlay">
        <i class="sui-icon-loader sui-loading" aria-hidden="true"></i>
    </div>
</template>

<script>
    export default {
        name: "overlay"
    }
</script>