

<?php
require($_SERVER['DOCUMENT_ROOT'].'/wp-load.php');
global $wpdb;
	$today = date('Y-m-d');
	$ninetydaysago = date('Y-m-d', strtotime('-30 days'));

	$api_token = get_field('api_token', 'option');
	$api_secret = get_field('api_secret', 'option');
	$account_id = get_field('account_id', 'option');
	$colon = ":";

	$client = new Client();
        $url = "https://app.ninjacat.io/open_api";
        $agencyId = -1; // replace with correct agency id
        $advertiserId = "10039108"; //replace with correct account id
        $key = "secret";

        $payLoad = [
            "agency_id" => $agencyId,
            "template_id" => $templateId,
            "advertiser_id" => $advertiserId
        ];

        $token = JWT::encode($payLoad, $key);

        $options = [
            "form_params" => [
                "start_date" => $startDate,
                "end_date" => $endDate
            ],
            "headers" => [
                'Accept' => 'application/json',
                'Authorization' => "Bearer $token"
            ]
        ];

        $response = $client->post("$url/$agencyId/$templateId/$advertiserId", $options);

        $result = json_decode($response->getBody());

?>

<?php include 'header-inc.php';?>
<div class="cybermark-support__wrapper">
	<div class="container">
		<div class="cybermark-support__inner">
			<div class="cybermark-support__chart">
				<div class="row">
					<div class="col-md-9">
						<div class="panel">
							<div class="panel-body">
								<?php
	echo '<pre>';
	print_r($result);
	echo '</pre>';

?>
							</div>
						</div>
					</div>
					<div class="col-md-3">
						<div class="callouts">
							<div class="callout_box leads_box">
								<a href="<?php echo admin_url();?>admin.php?page=lead_tracking">
									<h6>CyberMark Lead Tracking</h6>
									<p>Looking for your leads? We have them conveniently located inside the Website Dashboard. Use this link or the one at the top of the page to view your leads from the past 30 days.</p>
									<span class=" btn btn-lg">My Leads</span>
								</a>
							</div>
							<div class="callout_box support_box">
								<a href="<?php echo admin_url();?>admin.php?page=lead_tracking">
									<h6>CyberMark SMART Support</h6>
									<p>Need help updating your site? Want to make a change to your marketing campaign? Looking to add new services or update your billing methods? Our CyberMark SMART Support team is here to help!</p>
									<span class=" btn btn-lg">Support Request</span>
								</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

