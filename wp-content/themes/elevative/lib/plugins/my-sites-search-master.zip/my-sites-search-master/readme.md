# My Sites Search

Provides a simple filtering mechanism for finding items in a large My Sites menu.

|Before|After|
|------|-----|
|![mss-before](mss-before.png)  |![mss-after](mss-after.png)   |