export default {
    methods: {
        get_footer: function () {

        },
        get_premium_footer: function () {

        }
    }
}