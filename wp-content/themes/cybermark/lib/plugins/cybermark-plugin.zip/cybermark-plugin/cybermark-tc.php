<?php
/**
 * @package CyberMark 
 * @version 2.0
 */
/*
Plugin Name: CyberMark Plugin
Plugin URI: 
Description: 
Author: CyberMark
Version: 2.0
Author URI: https://www.cybermark.com
*/



// Update Wordpress Dashboard Layout. Include CyberMark branding
function admin_style_main() {
  wp_enqueue_style('cybermark-tc', plugins_url('/style.css', __FILE__));
}
add_action('admin_enqueue_scripts', 'admin_style_main');

/*Create CyberMark custom login screen */
function my_custom_login() {
  wp_enqueue_style('cybermark-tc', plugins_url('/style.css', __FILE__));
}
add_action('login_head', 'my_custom_login');

//Remove admin bar
add_action('after_setup_theme', 'wpb_remove_admin_bar');
  
function wpb_remove_admin_bar() {
if (!current_user_can('administrator') && !is_admin()) {
  show_admin_bar(false);
}
}

//Update Footer Text
function remove_footer_admin () {
    echo "CyberMark Franchise Platform";
} 
add_filter('admin_footer_text', 'remove_footer_admin');



//Add Custom CyberMark menu items to dashboard, this can be edited later for brands

add_action( 'admin_menu', 'mt_add_pages' );
add_action( 'admin_head', 'redirect_custom_menu' );
function mt_add_pages() {
    add_menu_page( 'reports', 'Reporting', 'read', 'custom_report_page','', 'dashicons-chart-line' ,  1 );
}
function redirect_custom_menu(){
    ?>
    <script type="text/javascript">
        jQuery(document).ready( function($) {   
            $('a.toplevel_page_custom_report_page').attr('href','https://reports.cybermark.com/login').attr('target','_blank'); 
        });
    </script>
    <?php
}
// disable default dashboard widgets
function disable_default_dashboard_widgets() {

  remove_meta_box('dashboard_right_now', 'dashboard', 'core');
  remove_meta_box('dashboard_activity', 'dashboard', 'core');
  remove_meta_box('dashboard_recent_comments', 'dashboard', 'core');
  remove_meta_box('dashboard_incoming_links', 'dashboard', 'core');
  remove_meta_box('dashboard_plugins', 'dashboard', 'core');

  remove_meta_box('dashboard_quick_press', 'dashboard', 'core');
  remove_meta_box('dashboard_recent_drafts', 'dashboard', 'core');
  remove_meta_box('dashboard_primary', 'dashboard', 'core');
  remove_meta_box('dashboard_secondary', 'dashboard', 'core');
}
add_action('admin_menu', 'disable_default_dashboard_widgets');


// Add Support Widget
function support_dashboard_widget() {
  echo '<img src="' . plugins_url('/support.png', __FILE__) .'" alt=""/>';
  echo "<p>Need help updating your site? Our CyberMark SMART Support team is here to help! Click the button below and fill out a support request or use the online support link on the right.</p>";
  echo "<a href='admin.php?page=cybermark_support' class='button cybermark-button'>Request Support</a>";
}
function sales_dashboard_widget() {
  echo '<img src="' . plugins_url('/sales.png', __FILE__) .'" alt=""/>';
  echo "<p>Questions about marketing? Looking to start marketing with CyberMark? Click the link below, fill out the form and a member of our team will reach out to you. </p>";
  echo "<a href='https://www.cybermark.com/contact/' target='_blank' class='button cybermark-button'>Request Information</a>";
}
function reports_dashboard_widget() {
  echo '<img src="' . plugins_url('/reporting.png', __FILE__) .'" alt=""/>';
  echo "<p>Login to your dashboard to view your monthly reporting. This report includes your micro-site and marketing performance, as well as view real-time data.</p>";
  echo "<a href='https://reports.cybermark.com/login' target='_blank' class='button cybermark-button'>Access Reports</a>";
}
function tracking_dashboard_widget() {
  echo '<img src="' . plugins_url('/lead-tracking.png', __FILE__) .'" alt=""/>';
  echo "<p>Easily see how many leads you’re getting and from which sources, whether it’s an SEO or PPC campaign. Rate the quality of the lead or tag the lead with a sales value to calculate ROI.</p>";
  echo "<a href='admin.php?page=lead_tracking' class='button cybermark-button'>View Your Leads</a>";
}
function add_custom_dashboard_widget() {
  wp_add_dashboard_widget('support_dashboard_widget', 'CyberMark SMART Support', 'support_dashboard_widget');
  wp_add_dashboard_widget('sales_dashboard_widget', 'CyberMark Sales', 'sales_dashboard_widget');
  wp_add_dashboard_widget('reports_dashboard_widget', 'Reporting', 'reports_dashboard_widget');
  wp_add_dashboard_widget('tracking_dashboard_widget', 'Lead Tracking', 'tracking_dashboard_widget');
}
add_action('wp_dashboard_setup', 'add_custom_dashboard_widget');

//Add Zendesk Widget

function custom_admin_js() {
    $url = get_bloginfo('template_directory') . '/js/wp-admin.js';
echo '<script>window.fwSettings={"widget_id":48000000156};!function(){if("function"!=typeof window.FreshworksWidget){var n=function(){n.q.push(arguments)};n.q=[],window.FreshworksWidget=n}}() </script>';
echo '<script type="text/javascript" src="https://widget.freshworks.com/widgets/48000000156.js" async defer></script>';
}
add_action('admin_footer', 'custom_admin_js');



//Disable Screen Options
function wpb_remove_screen_options() { 

}
add_filter('screen_options_show_screen', 'wpb_remove_screen_options');

//Disable Help Tab
add_action('admin_head', 'mytheme_remove_help_tabs');
function mytheme_remove_help_tabs() {
    $screen = get_current_screen();
    $screen->remove_help_tabs();
}

// remove toolbar items
function remove_from_admin_bar($wp_admin_bar) {
    /*
     * Placing items in here will only remove them from admin bar
     * when viewing the fronte end of the site
    */
        // Example of removing item generated by plugin. Full ID is #wp-admin-bar-si_menu
        $wp_admin_bar->remove_node('si_menu');
 
        // WordPress Core Items (uncomment to remove)
        $wp_admin_bar->remove_node('updates');
        $wp_admin_bar->remove_node('comments');
        $wp_admin_bar->remove_node('new-content');
        $wp_admin_bar->remove_node('wp-logo');
        //$wp_admin_bar->remove_node('site-name');
        //$wp_admin_bar->remove_node('my-account');
        $wp_admin_bar->remove_node('search');
        $wp_admin_bar->remove_node('customize');
 
    /*
     * Items placed outside the if statement will remove it from both the frontend
     * and backend of the site
    */
    $wp_admin_bar->remove_node('wp-logo');
}
add_action('admin_bar_menu', 'remove_from_admin_bar', 999);


//CyberMark Online Presence Location Information Custom Post
function location_information() {

    /**
     * Post Type: Location Information.
     */

    $labels = array(
        "name" => __( "Location Information", "cybermark" ),
        "singular_name" => __( "Location Information", "cybermark" ),
        "menu_name" => __( "Location Information", "cybermark" ),
    );

    $args = array(
        "label" => __( "Location Information", "cybermark" ),
        "labels" => $labels,
        "description" => "",
        "public" => true,
        "publicly_queryable" => false,
        "show_ui" => true,
        "show_in_rest" => true,
        "rest_base" => "",
        "has_archive" => true,
        "show_in_menu" => false,
        "show_in_nav_menus" => false,
        "exclude_from_search" => true,
        "capability_type" => "post",
        "map_meta_cap" => true,
        "hierarchical" => true,
        "rewrite" => array( "slug" => "location_information", "with_front" => true ),
        "query_var" => false,
        "menu_position" => 1,
        "menu_icon" => "dashicons-location-alt",
        "supports" => array( "editor", "custom-fields", "revisions" ),
    );

    register_post_type( "location_information", $args );
}

add_action( 'init', 'location_information' );

add_action( 'admin_menu', 'linked_url' );
    function linked_url() {
    add_menu_page( 'linked_url', 'Location Information', 'edit_posts', 'post.php?post=999999&action=edit', '', 'dashicons-location-alt', 1 );
    }
    
//Hide Publishing Box on Online Presence Information
function hide_publishing_actions(){
        $my_post_type = 'location_information';
        global $post;
        if($post->post_type == $my_post_type){
            echo '
                <style type="text/css">
                    #misc-publishing-actions,
                    #side-sortables .hndle.ui-sortable-handle,
                    #delete-action,
                    #minor-publishing-actions{
                        display:none;
                    }
                </style>
            ';
        }
}
add_action('admin_head-post.php', 'hide_publishing_actions');
add_action('admin_head-post-new.php', 'hide_publishing_actions');
/**
 * Register `team` post type
 */
function team_post_type() {

   // Labels
  $labels = array(
    'name' => _x("Team", "post type general name"),
    'singular_name' => _x("Team", "post type singular name"),
    'menu_name' => 'Team Profiles',
    'add_new' => _x("Add New", "team item"),
    'add_new_item' => __("Add New Profile"),
    'edit_item' => __("Edit Profile"),
    'new_item' => __("New Profile"),
    'view_item' => __("View Profile"),
    'search_items' => __("Search Profiles"),
    'not_found' =>  __("No Profiles Found"),
    'not_found_in_trash' => __("No Profiles Found in Trash"),
    'parent_item_colon' => ''
  );

  // Register post type
  register_post_type('team' , array(
    'labels' => $labels,
    'public' => true,
    "publicly_queryable" => false,
    "show_ui" => true,
    "show_in_rest" => false,
    "rest_base" => "",
    "has_archive" => true,
    "show_in_menu" => true,
    "show_in_nav_menus" => false,
    "exclude_from_search" => true,
    'has_archive' => true,
    'menu_icon'   => 'dashicons-groups',
    'menu_position' => 7,
    'rewrite' => false,
    "supports" => array( "title","editor", "custom-fields", "revisions" ),
  ) );
}
add_action( 'init', 'team_post_type', 0 );


//CyberMark Landing Page custom post
function cpts_landing_page() {


    $labels = array(
        "name" => __( "Landing Page", "cybermark" ),
        "singular_name" => __( "Landing Page", "cybermark" ),
        "menu_name" => __( "Landing Pages", "cybermark" ),
        "all_items" => __( "All Landing Pages", "cybermark" ),
        "add_new" => __( "Add Landing Page", "cybermark" ),
        "add_new_item" => __( "Add New Landing Page", "cybermark" ),
        "edit_item" => __( "Edit Landing Page", "cybermark" ),
        "new_item" => __( "New Landing Page", "cybermark" ),
        "view_item" => __( "View Landing Pages", "cybermark" ),
        "view_items" => __( "View Landing Pages", "cybermark" ),
        "search_items" => __( "Search Landing Pages", "cybermark" ),
        "not_found" => __( "No Landing Pages Found", "cybermark" ),
    );

    $args = array(
        "label" => __( "Landing Page", "cybermark" ),
        "labels" => $labels,
        "description" => "Display your Landing Pages",
        "public" => true,
        "publicly_queryable" => true,
        "show_ui" => true,
        "show_in_rest" => false,
        "rest_base" => "",
        "has_archive" => false,
        "show_in_menu" => true,
        "show_in_nav_menus" => false,
        "exclude_from_search" => true,
        "capability_type" => "post",
        "map_meta_cap" => true,
        "hierarchical" => false,
        "rewrite" => array( "slug" => "offer", "with_front" => false ),
        "menu_position" => 0,
        'menu_icon'   => 'dashicons-align-left',
        "query_var" => true,
        "supports" => array( "title", "editor", "thumbnail"),
    );

    register_post_type( "landing-pages", $args );
}
add_action( 'init', 'cpts_landing_page' );




function cm_specials() {

    /**
     * Post Type: Specials.
     */

    $labels = array(
        "name" => __( "Specials", "cybermark" ),
        "singular_name" => __( "Special", "cybermark" ),
        "menu_name" => __( "Specials", "cybermark" ),
        "all_items" => __( "All Specials", "cybermark" ),
        "add_new" => __( "Add Special", "cybermark" ),
        "add_new_item" => __( "Add New Specials", "cybermark" ),
        "edit_item" => __( "Edit Special", "cybermark" ),
        "new_item" => __( "New Special", "cybermark" ),
        "view_item" => __( "View Special", "cybermark" ),
        "view_items" => __( "View Specials", "cybermark" ),
        "search_items" => __( "Search Specials", "cybermark" ),
        "not_found" => __( "No Specials Found", "cybermark" ),
        "not_found_in_trash" => __( "No Specials in Trash", "cybermark" ),
    );

    $args = array(
        "label" => __( "Specials", "cybermark" ),
        "labels" => $labels,
        "description" => "",
        "public" => true,
        "publicly_queryable" => true,
        "show_ui" => true,
        "show_in_rest" => false,
        "rest_base" => "",
        "has_archive" => true,
        "show_in_menu" => true,
        "show_in_nav_menus" => true,
        "exclude_from_search" => false,
        "capability_type" => "post",
        "map_meta_cap" => true,
        'menu_position' => 7,
        'menu_icon'   => 'dashicons-tickets-alt',
        "hierarchical" => false,
        "rewrite" => array( "slug" => "specials", "with_front" => true ),
        "query_var" => true,
        "supports" => array( "title", "editor", "thumbnail" ),
    );

    register_post_type( "specials", $args );
}



add_action( 'init', 'cm_specials' );

//ACF For Custom Posts and Pages
if( function_exists('acf_add_local_field_group') ):

acf_add_local_field_group(array(
  'key' => 'group_5afdb21a688df-2',
  'title' => 'Location Admin',
  'fields' => array(
    array(
      'key' => 'field_5bbb942bcaa8a',
      'label' => 'Custom Scripts',
      'name' => '',
      'type' => 'tab',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'placement' => 'left',
      'endpoint' => 0,
    ),
    array(
      'key' => 'field_5afdb27ae7c33',
      'label' => 'CyberMark Lead Tracking',
      'name' => 'cybermark_lead_tracking',
      'type' => 'text',
      'instructions' => 'Enter the What Converts ID only',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5afdb2e3a64fe',
      'label' => 'Google Tag Manager (head)',
      'name' => 'google_tag_manager_head',
      'type' => 'textarea',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '50',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'maxlength' => '',
      'rows' => '',
      'new_lines' => '',
    ),
    array(
      'key' => 'field_5afdb2f6a64ff',
      'label' => 'Google Tag Manager (body)',
      'name' => 'google_tag_manager_body',
      'type' => 'textarea',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '50',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'maxlength' => '',
      'rows' => '',
      'new_lines' => '',
    ),
    array(
      'key' => 'field_5afdb29de7c35',
      'label' => 'Header Scripts',
      'name' => 'header_scripts',
      'type' => 'textarea',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '50',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'maxlength' => '',
      'rows' => '',
      'new_lines' => '',
    ),
    array(
      'key' => 'field_5afdb2aae7c36',
      'label' => 'Footer Scripts',
      'name' => 'footer_scripts',
      'type' => 'textarea',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '50',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'maxlength' => '',
      'rows' => '',
      'new_lines' => '',
    ),
    
    array(
      'key' => 'field_5c01538b2bf53',
      'label' => 'Location Information',
      'name' => '',
      'type' => 'tab',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'placement' => 'left',
      'endpoint' => 0,
    ),
    array(
      'key' => 'field_5baebbafdddea',
      'label' => 'Template',
      'name' => 'template',
      'type' => 'radio',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'choices' => array(
        'comingsoon' => 'Coming Soon',
        'pre_open' => 'Pre Opening',
        'open' => 'Open',
      ),
      'allow_null' => 0,
      'other_choice' => 0,
      'default_value' => '',
      'layout' => 'horizontal',
      'return_format' => 'value',
      'save_other_choice' => 0,
    ),
    array(
      'key' => 'field_5c0154212bf55',
      'label' => 'Location Name',
      'name' => 'location_name',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '50',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c01542e2bf56',
      'label' => 'Location Phone Number',
      'name' => 'location_phone_number',
      'type' => 'text',
      'instructions' => 'Use format: (555) 555-1234',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '50',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c0154392bf57',
      'label' => 'Location Address',
      'name' => 'location_address',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c0154462bf58',
      'label' => 'Location City',
      'name' => 'location_city',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c01544f2bf59',
      'label' => 'Location State',
      'name' => 'location_state',
      'type' => 'text',
      'instructions' => 'Please use two digit state code only',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => 2,
    ),
    array(
      'key' => 'field_5c0154842bf5a',
      'label' => 'Location Zip Code',
      'name' => 'location_zip_code',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c01549c2bf5c',
      'label' => 'Location Longitude',
      'name' => 'location_longitude',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '50',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c0154922bf5b',
      'label' => 'Location Latitude',
      'name' => 'location_latitude',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '50',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c7d8e8f7fdb0',
      'label' => 'Business Hours',
      'name' => '',
      'type' => 'tab',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'placement' => 'left',
      'endpoint' => 0,
    ),
    array(
      'key' => 'field_5c7d8ef77fdb1',
      'label' => 'Hours Monday',
      'name' => 'hours_monday',
      'type' => 'text',
      'instructions' => 'Format like this: 8am - 6pm',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c7d8f317fdb2',
      'label' => 'Hours Tuesday',
      'name' => 'hours_tuesday',
      'type' => 'text',
      'instructions' => 'Format like this: 8am - 6pm',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c7d8f3b7fdb3',
      'label' => 'Hours Wednesday',
      'name' => 'hours_wednesday',
      'type' => 'text',
      'instructions' => 'Format like this: 8am - 6pm',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c7d8f4a7fdb4',
      'label' => 'Hours Thursday',
      'name' => 'hours_thursday',
      'type' => 'text',
      'instructions' => 'Format like this: 8am - 6pm',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c7d8f537fdb5',
      'label' => 'Hours Friday',
      'name' => 'hours_friday',
      'type' => 'text',
      'instructions' => 'Format like this: 8am - 6pm',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c7d8f5d7fdb6',
      'label' => 'Hours Saturday',
      'name' => 'hours_saturday',
      'type' => 'text',
      'instructions' => 'Format like this: 8am - 6pm',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c7d8f697fdb7',
      'label' => 'Hours Sunday',
      'name' => 'hours_sunday',
      'type' => 'text',
      'instructions' => 'Format like this: 8am - 6pm',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '100',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c7d8f8e795f3',
      'label' => 'About Page',
      'name' => '',
      'type' => 'tab',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'placement' => 'left',
      'endpoint' => 0,
    ),
    array(
      'key' => 'field_5c7d8fa3795f4',
      'label' => 'About Text',
      'name' => 'about_text',
      'type' => 'wysiwyg',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'tabs' => 'all',
      'toolbar' => 'full',
      'media_upload' => 1,
      'delay' => 0,
    ),
    array(
      'key' => 'field_5c0154a92bf5d',
      'label' => 'Social Media',
      'name' => '',
      'type' => 'tab',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'placement' => 'left',
      'endpoint' => 0,
    ),
    array(
      'key' => 'field_5c0154b72bf5e',
      'label' => 'Facebook URL',
      'name' => 'facebook_url',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c0154bf2bf5f',
      'label' => 'Twitter URL',
      'name' => 'twitter_url',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c0154c82bf60',
      'label' => 'Instagram URL',
      'name' => 'instagram',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c0154c82bf602',
      'label' => 'Yelp URL',
      'name' => 'yelp',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c0154c82bf603',
      'label' => 'Pinterest URL',
      'name' => 'pinterest',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
  ),
  'location' => array(
    array(
      array(
        'param' => 'post_type',
        'operator' => '==',
        'value' => 'location_information',
      ),
      array(
        'param' => 'current_user_role',
        'operator' => '==',
        'value' => 'super_admin',
      ),
    ),
    array(
      array(
        'param' => 'post_type',
        'operator' => '==',
        'value' => 'location_information',
      ),
      array(
        'param' => 'current_user_role',
        'operator' => '==',
        'value' => 'administrator',
      ),
    ),
  ),
  'menu_order' => 0,
  'position' => 'acf_after_title',
  'style' => 'default',
  'label_placement' => 'top',
  'instruction_placement' => 'field',
  'hide_on_screen' => array(
    0 => 'permalink',
    1 => 'the_content',
    2 => 'excerpt',
    3 => 'discussion',
    4 => 'comments',
    5 => 'slug',
    6 => 'author',
    7 => 'format',
    8 => 'page_attributes',
    9 => 'featured_image',
    10 => 'categories',
    11 => 'tags',
    12 => 'send-trackbacks',
  ),
  'active' => true,
  'description' => '',
));

acf_add_local_field_group(array(
  'key' => 'group_5b072beeec50f-2',
  'title' => 'Meta Information',
  'fields' => array(
    array(
      'key' => 'field_5b072c001bc4a',
      'label' => 'SEO Title',
      'name' => 'seo_title',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5b072c1c1bc4b',
      'label' => 'SEO Description',
      'name' => 'seo_description',
      'type' => 'textarea',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'maxlength' => '',
      'rows' => 4,
      'new_lines' => '',
    ),
  ),
  'location' => array(
    array(
      array(
        'param' => 'current_user_role',
        'operator' => '==',
        'value' => 'administrator',
      ),
      array(
        'param' => 'post_type',
        'operator' => '!=',
        'value' => 'location_information',
      ),
      array(
        'param' => 'post_type',
        'operator' => '!=',
        'value' => 'specials',
      ),
      array(
        'param' => 'post_type',
        'operator' => '!=',
        'value' => 'team',
      ),
      array(
        'param' => 'post_type',
        'operator' => '!=',
        'value' => 'testimonials',
      ),
    ),
  ),
  'menu_order' => 0,
  'position' => 'acf_after_title',
  'style' => 'default',
  'label_placement' => 'top',
  'instruction_placement' => 'label',
  'hide_on_screen' => '',
  'active' => true,
  'description' => '',
));
acf_add_local_field_group(array(
  'key' => 'group_5d7a6e3d355a6',
  'title' => 'CyberMark Settings',
  'fields' => array(
    array(
      'key' => 'field_5d7a6e67e6948',
      'label' => 'API Token',
      'name' => 'api_token',
      'type' => 'text',
      'instructions' => 'Please enter the What Converts API Token here.',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5d7a6e7ee6949',
      'label' => 'API Secret',
      'name' => 'api_secret',
      'type' => 'text',
      'instructions' => 'Please enter the What Converts API Secret here.',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5d7a6f72ae8d7',
      'label' => 'Account ID',
      'name' => 'account_id',
      'type' => 'text',
      'instructions' => 'Please enter the What Converts Account ID here',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
  ),
  'location' => array(
    array(
      array(
        'param' => 'options_page',
        'operator' => '==',
        'value' => 'franchise-settings',
      ),
      array(
        'param' => 'current_user_role',
        'operator' => '==',
        'value' => 'super_admin',
      ),
    ),
  ),
  'menu_order' => 0,
  'position' => 'acf_after_title',
  'style' => 'default',
  'label_placement' => 'top',
  'instruction_placement' => 'label',
  'hide_on_screen' => array(
    0 => 'permalink',
    1 => 'the_content',
    2 => 'excerpt',
    3 => 'discussion',
    4 => 'comments',
    5 => 'revisions',
    6 => 'slug',
    7 => 'author',
    8 => 'format',
    9 => 'page_attributes',
    10 => 'featured_image',
    11 => 'categories',
    12 => 'tags',
    13 => 'send-trackbacks',
  ),
  'active' => true,
  'description' => '',
));
acf_add_local_field_group(array(
  'key' => 'group_5c6492e720efc',
  'title' => 'Franchise Settings',
  'fields' => array(
    array(
      'key' => 'field_5c65e777fcc3c',
      'label' => 'Basic Information',
      'name' => '',
      'type' => 'tab',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'placement' => 'top',
      'endpoint' => 0,
    ),
    array(
      'key' => 'field_5c6495d423273',
      'label' => 'Franchise Logo',
      'name' => 'franchise_logo',
      'type' => 'image',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'return_format' => 'array',
      'preview_size' => 'thumbnail',
      'library' => 'all',
      'min_width' => '',
      'min_height' => '',
      'min_size' => '',
      'max_width' => '',
      'max_height' => '',
      'max_size' => '',
      'mime_types' => '',
    ),
    array(
      'key' => 'field_5c65df9144a8c',
      'label' => 'Franchise Name',
      'name' => 'franchise_name',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '50',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c65dfa944a8e',
      'label' => 'Franchise Phone',
      'name' => 'franchise_phone',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '50',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c65dfbd44a8f',
      'label' => 'Franchise Address',
      'name' => 'franchise_address',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '100',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c65dfc444a90',
      'label' => 'Franchise City',
      'name' => 'franchise_city',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c65dfd644a91',
      'label' => 'Franchise State',
      'name' => 'franchise_state',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => 2,
    ),
    array(
      'key' => 'field_5c65dfe344a92',
      'label' => 'Franchise Zip Code',
      'name' => 'franchise_zip_code',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => 5,
    ),
    array(
      'key' => 'field_5c65e7a2fcc3e',
      'label' => 'Social Media',
      'name' => '',
      'type' => 'tab',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'placement' => 'top',
      'endpoint' => 0,
    ),
    array(
      'key' => 'field_5c65e716fcc3b',
      'label' => 'Facebook',
      'name' => 'facebook',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c65e7d0316c0',
      'label' => 'Twitter',
      'name' => 'twitter',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c65e7fd316c1',
      'label' => 'Instagram',
      'name' => 'instagram',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c65e808316c2',
      'label' => 'YouTube',
      'name' => 'youtube',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c65e835316c4',
      'label' => 'Yelp',
      'name' => 'yelp',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c65e78bfcc3d',
      'label' => 'Website Tracking Scripts',
      'name' => '',
      'type' => 'tab',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'placement' => 'top',
      'endpoint' => 0,
    ),
    array(
      'key' => 'field_5c6492ee2bb67',
      'label' => 'Lead Tracking Script',
      'name' => 'lead_tracking_script',
      'type' => 'text',
      'instructions' => 'Enter your CyberMark tracking script ID only',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '100',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c64937c2bb68',
      'label' => 'Header Scripts',
      'name' => 'header_scripts',
      'type' => 'textarea',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'maxlength' => '',
      'rows' => 4,
      'new_lines' => '',
    ),
    array(
      'key' => 'field_5c6493b42bb6a',
      'label' => 'Body Scripts',
      'name' => 'body_scripts',
      'type' => 'textarea',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'maxlength' => '',
      'rows' => 4,
      'new_lines' => '',
    ),
    array(
      'key' => 'field_5c6493982bb69',
      'label' => 'Footer Scripts',
      'name' => 'header_scripts',
      'type' => 'textarea',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'maxlength' => '',
      'rows' => 4,
      'new_lines' => '',
    ),
  ),
  'location' => array(
    array(
      array(
        'param' => 'options_page',
        'operator' => '==',
        'value' => 'franchise-settings',
      ),
      array(
        'param' => 'current_user_role',
        'operator' => '==',
        'value' => 'super_admin',
      ),
    ),
    array(
      array(
        'param' => 'options_page',
        'operator' => '==',
        'value' => 'franchise-settings',
      ),
      array(
        'param' => 'current_user_role',
        'operator' => '==',
        'value' => 'administrator',
      ),
    ),
  ),
  'menu_order' => 0,
  'position' => 'acf_after_title',
  'style' => 'default',
  'label_placement' => 'top',
  'instruction_placement' => 'label',
  'hide_on_screen' => array(
    0 => 'permalink',
    1 => 'the_content',
    2 => 'excerpt',
    3 => 'discussion',
    4 => 'comments',
    5 => 'revisions',
    6 => 'slug',
    7 => 'author',
    8 => 'format',
    9 => 'page_attributes',
    10 => 'featured_image',
    11 => 'categories',
    12 => 'tags',
    13 => 'send-trackbacks',
  ),
  'active' => true,
  'description' => '',
));
acf_add_local_field_group(array(
  'key' => 'group_5c95050705617',
  'title' => 'Team Profiles',
  'fields' => array(
    array(
      'key' => 'field_5c95050c9c8de',
      'label' => 'Employee Name',
      'name' => 'employee_name',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '50',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c9505199c8df',
      'label' => 'Employee Position',
      'name' => 'employee_position',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '50',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c9505bb28521',
      'label' => 'Employee Photo',
      'name' => 'employee_photo',
      'type' => 'image',
      'instructions' => 'Min upload size of 450px X 450px',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '50',
        'class' => '',
        'id' => '',
      ),
      'return_format' => 'url',
      'preview_size' => 'thumbnail',
      'library' => 'all',
      'min_width' => 450,
      'min_height' => 450,
      'min_size' => '',
      'max_width' => '',
      'max_height' => '',
      'max_size' => '',
      'mime_types' => '',
    ),
    array(
      'key' => 'field_5c9505289c8e0',
      'label' => 'About',
      'name' => 'about',
      'type' => 'wysiwyg',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '50',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'tabs' => 'all',
      'toolbar' => 'basic',
      'media_upload' => 0,
      'delay' => 0,
    ),
    
  ),
  'location' => array(
    array(
      array(
        'param' => 'post_type',
        'operator' => '==',
        'value' => 'team',
      ),
    ),
  ),
  'menu_order' => 0,
  'position' => 'normal',
  'style' => 'default',
  'label_placement' => 'top',
  'instruction_placement' => 'label',
  'hide_on_screen' => array(
    0 => 'the_content',
    1 => 'excerpt',
    2 => 'discussion',
    3 => 'comments',
    4 => 'revisions',
    5 => 'author',
    6 => 'format',
    7 => 'featured_image',
    8 => 'categories',
    9 => 'tags',
    10 => 'send-trackbacks',
  ),
  'active' => true,
  'description' => '',
));

acf_add_local_field_group(array(
  'key' => 'group_5c211cb95db9f',
  'title' => 'Testimonials',
  'fields' => array(
    array(
      'key' => 'field_5c211cbe05a47',
      'label' => 'Client\'s Name',
      'name' => 'clients_name',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c86df847224a',
      'label' => 'Client Image',
      'name' => 'client_image',
      'type' => 'image',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'return_format' => 'array',
      'preview_size' => 'thumbnail',
      'library' => 'all',
      'min_width' => '',
      'min_height' => '',
      'min_size' => '',
      'max_width' => '',
      'max_height' => '',
      'max_size' => '',
      'mime_types' => '',
    ),
    array(
      'key' => 'field_5c211dcd4b41f',
      'label' => 'Review Details',
      'name' => 'review_details',
      'type' => 'wysiwyg',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'tabs' => 'all',
      'toolbar' => 'full',
      'media_upload' => 0,
      'delay' => 0,
    ),
  ),
  'location' => array(
    array(
      array(
        'param' => 'post_type',
        'operator' => '==',
        'value' => 'testimonials',
      ),
    ),
  ),
  'menu_order' => 0,
  'position' => 'normal',
  'style' => 'default',
  'label_placement' => 'top',
  'instruction_placement' => 'label',
  'hide_on_screen' => array(
    0 => 'permalink',
    1 => 'the_content',
    2 => 'excerpt',
    3 => 'discussion',
    4 => 'comments',
    5 => 'revisions',
    6 => 'slug',
    7 => 'author',
    8 => 'format',
    9 => 'page_attributes',
    10 => 'featured_image',
    11 => 'categories',
    12 => 'tags',
    13 => 'send-trackbacks',
  ),
  'active' => true,
  'description' => '',
));
acf_add_local_field_group(array(
  'key' => 'group_5beb54c7f27c0-2',
  'title' => 'Crawlable Page',
  'fields' => array(
    array(
      'key' => 'field_5beb54ebf31e1',
      'label' => 'Block Page',
      'name' => 'block_page',
      'type' => 'checkbox',
      'instructions' => 'To block this page from being crawled by search engines, check the box below:',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'choices' => array(
        'block' => 'Block',
      ),
      'allow_custom' => 0,
      'default_value' => array(
      ),
      'layout' => 'vertical',
      'toggle' => 0,
      'return_format' => 'value',
      'save_custom' => 0,
    ),
  ),
  'location' => array(
    array(
      array(
        'param' => 'post_type',
        'operator' => '==',
        'value' => 'page',
      ),
    ),
    array(
      array(
        'param' => 'post_type',
        'operator' => '==',
        'value' => 'landing-pages',
      ),
    ),
  ),
  'menu_order' => 0,
  'position' => 'side',
  'style' => 'default',
  'label_placement' => 'top',
  'instruction_placement' => 'label',
  'hide_on_screen' => array(
    0 => 'permalink',
    1 => 'the_content',
    2 => 'excerpt',
    3 => 'discussion',
    4 => 'comments',
    5 => 'revisions',
    6 => 'slug',
    7 => 'author',
    8 => 'format',
    9 => 'featured_image',
    10 => 'categories',
    11 => 'tags',
    12 => 'send-trackbacks',
  ),
  'active' => true,
  'description' => '',
));
acf_add_local_field_group(array(
  'key' => 'group_5b870a04810fa-2',
  'title' => 'Custom Scripts',
  'fields' => array(
    array(
      'key' => 'field_5b589c6e70409',
      'label' => 'Header Scripts',
      'name' => 'header_scripts',
      'type' => 'textarea',
      'instructions' => 'Use this area to display custom scripts for tracking in the head area of the page.',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '50',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'maxlength' => '',
      'rows' => 3,
      'new_lines' => '',
    ),
    array(
      'key' => 'field_5c7d902e2d7a6',
      'label' => 'Footer Scripts',
      'name' => 'footer_scripts',
      'type' => 'textarea',
      'instructions' => 'Use this area to display custom scripts for tracking in the footer area of the page.',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '50',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'maxlength' => '',
      'rows' => 3,
      'new_lines' => '',
    ),
  ),
  'location' => array(
    array(
      array(
        'param' => 'post_type',
        'operator' => '==',
        'value' => 'page',
      ),
    ),
    array(
      array(
        'param' => 'post_type',
        'operator' => '==',
        'value' => 'landing-pages',
      ),
    ),
  ),
  'menu_order' => 10,
  'position' => 'normal',
  'style' => 'default',
  'label_placement' => 'top',
  'instruction_placement' => 'label',
  'hide_on_screen' => array(
    0 => 'the_content',
    1 => 'excerpt',
    2 => 'discussion',
    3 => 'comments',
    4 => 'revisions',
    5 => 'slug',
    6 => 'author',
    7 => 'format',
    8 => 'featured_image',
    9 => 'categories',
    10 => 'tags',
    11 => 'send-trackbacks',
  ),
  'active' => true,
  'description' => '',
));

acf_add_local_field_group(array(
  'key' => 'group_5afdb21a688df-2',
  'title' => 'Location Admin',
  'fields' => array(
    array(
      'key' => 'field_5bbb942bcaa8a',
      'label' => 'Custom Scripts',
      'name' => '',
      'type' => 'tab',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'placement' => 'left',
      'endpoint' => 0,
    ),
    array(
      'key' => 'field_5afdb27ae7c33',
      'label' => 'CyberMark Lead Tracking',
      'name' => 'cybermark_lead_tracking',
      'type' => 'text',
      'instructions' => 'Enter the What Converts ID only',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5afdb2e3a64fe',
      'label' => 'Google Tag Manager (head)',
      'name' => 'google_tag_manager_head',
      'type' => 'textarea',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '50',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'maxlength' => '',
      'rows' => '',
      'new_lines' => '',
    ),
    array(
      'key' => 'field_5afdb2f6a64ff',
      'label' => 'Google Tag Manager (body)',
      'name' => 'google_tag_manager_body',
      'type' => 'textarea',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '50',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'maxlength' => '',
      'rows' => '',
      'new_lines' => '',
    ),
    array(
      'key' => 'field_5afdb29de7c35',
      'label' => 'Header Scripts',
      'name' => 'header_scripts',
      'type' => 'textarea',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '50',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'maxlength' => '',
      'rows' => '',
      'new_lines' => '',
    ),
    array(
      'key' => 'field_5afdb2aae7c36',
      'label' => 'Footer Scripts',
      'name' => 'footer_scripts',
      'type' => 'textarea',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '50',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'maxlength' => '',
      'rows' => '',
      'new_lines' => '',
    ),
    array(
      'key' => 'field_5c01538b2bf53',
      'label' => 'Location Information',
      'name' => '',
      'type' => 'tab',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'placement' => 'left',
      'endpoint' => 0,
    ),
    array(
      'key' => 'field_5baebbafdddea',
      'label' => 'Template',
      'name' => 'template',
      'type' => 'radio',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'choices' => array(
        'comingsoon' => 'Coming Soon',
        'open' => 'Open',
      ),
      'allow_null' => 0,
      'other_choice' => 0,
      'default_value' => '',
      'layout' => 'horizontal',
      'return_format' => 'value',
      'save_other_choice' => 0,
    ),
    array(
      'key' => 'field_5c0154212bf55',
      'label' => 'Location Name',
      'name' => 'location_name',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '50',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c01542e2bf56',
      'label' => 'Location Phone Number',
      'name' => 'location_phone_number',
      'type' => 'text',
      'instructions' => 'Use format: (555) 555-1234',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '50',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c3780601e245',
      'label' => 'Location Email',
      'name' => 'location_email',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '50',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c93d327f1623',
      'label' => 'Location Owner Name',
      'name' => 'location_owner',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '50',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c0154392bf57',
      'label' => 'Location Address',
      'name' => 'location_address',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c0154462bf58',
      'label' => 'Location City',
      'name' => 'location_city',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c01544f2bf59',
      'label' => 'Location State',
      'name' => 'location_state',
      'type' => 'text',
      'instructions' => 'Please use two digit state code only',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => 2,
    ),
    array(
      'key' => 'field_5c0154842bf5a',
      'label' => 'Location Zip Code',
      'name' => 'location_zip_code',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c01549c2bf5c',
      'label' => 'Location Longitude',
      'name' => 'location_longitude',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '50',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c0154922bf5b',
      'label' => 'Location Latitude',
      'name' => 'location_latitude',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '50',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c7d8e8f7fdb0',
      'label' => 'Business Hours',
      'name' => '',
      'type' => 'tab',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'placement' => 'left',
      'endpoint' => 0,
    ),
    array(
      'key' => 'field_5c7d8ef77fdb1',
      'label' => 'Hours Monday',
      'name' => 'hours_monday',
      'type' => 'text',
      'instructions' => 'Format like this: 8am - 6pm',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c7d8f317fdb2',
      'label' => 'Hours Tuesday',
      'name' => 'hours_tuesday',
      'type' => 'text',
      'instructions' => 'Format like this: 8am - 6pm',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c7d8f3b7fdb3',
      'label' => 'Hours Wednesday',
      'name' => 'hours_wednesday',
      'type' => 'text',
      'instructions' => 'Format like this: 8am - 6pm',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c7d8f4a7fdb4',
      'label' => 'Hours Thursday',
      'name' => 'hours_thursday',
      'type' => 'text',
      'instructions' => 'Format like this: 8am - 6pm',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c7d8f537fdb5',
      'label' => 'Hours Friday',
      'name' => 'hours_friday',
      'type' => 'text',
      'instructions' => 'Format like this: 8am - 6pm',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c7d8f5d7fdb6',
      'label' => 'Hours Saturday',
      'name' => 'hours_saturday',
      'type' => 'text',
      'instructions' => 'Format like this: 8am - 6pm',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '33',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c7d8f697fdb7',
      'label' => 'Hours Sunday',
      'name' => 'hours_sunday',
      'type' => 'text',
      'instructions' => 'Format like this: 8am - 6pm',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '100',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c7d8f8e795f3',
      'label' => 'About Page',
      'name' => '',
      'type' => 'tab',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'placement' => 'left',
      'endpoint' => 0,
    ),
    array(
      'key' => 'field_5c7d8fa3795f4',
      'label' => 'About Text',
      'name' => 'about_text',
      'type' => 'wysiwyg',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'tabs' => 'all',
      'toolbar' => 'full',
      'media_upload' => 1,
      'delay' => 0,
    ),
    array(
      'key' => 'field_5c0154a92bf5d',
      'label' => 'Social Media',
      'name' => '',
      'type' => 'tab',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'placement' => 'left',
      'endpoint' => 0,
    ),
    array(
      'key' => 'field_5c0154b72bf5e',
      'label' => 'Facebook URL',
      'name' => 'facebook_url',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c0154bf2bf5f',
      'label' => 'Twitter URL',
      'name' => 'twitter_url',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5c0154c82bf60',
      'label' => 'Instagram URL',
      'name' => 'instagram',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
  ),
  'location' => array(
    array(
      array(
        'param' => 'post_type',
        'operator' => '==',
        'value' => 'location_information',
      ),
      array(
        'param' => 'current_user_role',
        'operator' => '==',
        'value' => 'super_admin',
      ),
    ),
    array(
      array(
        'param' => 'post_type',
        'operator' => '==',
        'value' => 'location_information',
      ),
      array(
        'param' => 'current_user_role',
        'operator' => '==',
        'value' => 'administrator',
      ),
    ),
  ),
  'menu_order' => 0,
  'position' => 'acf_after_title',
  'style' => 'default',
  'label_placement' => 'top',
  'instruction_placement' => 'field',
  'hide_on_screen' => array(
    0 => 'permalink',
    1 => 'the_content',
    2 => 'excerpt',
    3 => 'discussion',
    4 => 'comments',
    5 => 'slug',
    6 => 'author',
    7 => 'format',
    8 => 'page_attributes',
    9 => 'featured_image',
    10 => 'categories',
    11 => 'tags',
    12 => 'send-trackbacks',
  ),
  'active' => true,
  'description' => '',
));

acf_add_local_field_group(array(
  'key' => 'group_5b072beeec50f-2',
  'title' => 'Meta Information',
  'fields' => array(
    array(
      'key' => 'field_5b072c001bc4a',
      'label' => 'SEO Title',
      'name' => 'seo_title',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5b072c1c1bc4b',
      'label' => 'SEO Description',
      'name' => 'seo_description',
      'type' => 'textarea',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'maxlength' => '',
      'rows' => 4,
      'new_lines' => '',
    ),
  ),
  'location' => array(
    array(
      array(
        'param' => 'current_user_role',
        'operator' => '==',
        'value' => 'administrator',
      ),
      array(
        'param' => 'post_type',
        'operator' => '!=',
        'value' => 'location_information',
      ),
      array(
        'param' => 'post_type',
        'operator' => '!=',
        'value' => 'specials',
      ),
      array(
        'param' => 'post_type',
        'operator' => '!=',
        'value' => 'team',
      ),
      array(
        'param' => 'post_type',
        'operator' => '!=',
        'value' => 'testimonials',
      ),
    ),
  ),
  'menu_order' => 0,
  'position' => 'acf_after_title',
  'style' => 'default',
  'label_placement' => 'top',
  'instruction_placement' => 'label',
  'hide_on_screen' => '',
  'active' => true,
  'description' => '',
));
endif;

//Custom TINYMCE Buttons

add_action('admin_head', 'cybermark_add_my_tc_button');
add_action('admin_enqueue_scripts', 'cybermark_tc_css');

function cybermark_add_my_tc_button() {
    global $typenow;
    // sprawdzamy czy user ma uprawnienia do edycji postów/podstron
    if ( !current_user_can('edit_posts') && !current_user_can('edit_pages') ) {
    return;
    }
    // weryfikujemy typ wpisu
    if( ! in_array( $typenow, array( 'post', 'page' ) ) )
        return;
  // sprawdzamy czy user ma włączony edytor WYSIWYG
  if ( get_user_option('rich_editing') == 'true') {
    add_filter("mce_external_plugins", "cybermark_add_tinymce_plugin");
    add_filter('mce_buttons', 'cybermark_register_my_tc_button');
  }
}

function cybermark_add_tinymce_plugin($plugin_array) {
    $plugin_array['cybermark_tc_button'] = plugins_url( '/complex-popup-button.js', __FILE__ ); // CHANGE THE BUTTON SCRIPT HERE
    return $plugin_array;
}

function cybermark_register_my_tc_button($buttons) {
   array_push($buttons, "cybermark_tc_button");
   return $buttons;
}

function cybermark_tc_css() {
  wp_enqueue_style('cybermark-tc', plugins_url('/style.css', __FILE__));
}

/**
 * Enable unfiltered_html capability for Editors.
 *
 * @param  array  $caps    The user's capabilities.
 * @param  string $cap     Capability name.
 * @param  int    $user_id The user ID.
 * @return array  $caps    The user's capabilities, with 'unfiltered_html' potentially added.
 */
function km_add_unfiltered_html_capability_to_editors( $caps, $cap, $user_id ) {
  if ( 'unfiltered_html' === $cap && user_can( $user_id, 'editor' ) ) {
    $caps = array( 'unfiltered_html' );
  }
  return $caps;
}
add_filter( 'map_meta_cap', 'km_add_unfiltered_html_capability_to_editors', 1, 3 );

function km_add_unfiltered_html_capability_to_admins( $caps, $cap, $user_id ) {
  if ( 'unfiltered_html' === $cap && user_can( $user_id, 'administrator' ) ) {
    $caps = array( 'unfiltered_html' );
  }
  return $caps;
}
add_filter( 'map_meta_cap', 'km_add_unfiltered_html_capability_to_admins', 1, 3 );

add_action( 'admin_head-post.php', 'scroll_to_top' );


//Add sticky Publish Button
function scroll_to_top() 
{
    ?>
    <style>
      #box {
        position: absolute;
        top: 20px;
        margin-left: -100px;
        right: 20px;
        text-align: center;
    }
    #box a {
      text-align: center;
      background-color: #fff;
      border: 2px solid #0079fe;
      text-decoration: none;
      padding: 10px 25px;
      color: #0079fe;
  }
    </style>

    <script type="text/javascript">
        jQuery(window).load( function() {   
            jQuery('<div id="box"><a href="#wpbody">Scroll to top</a></div>').appendTo("#wpbody-content");      

            function getScrollTop() {
            if (typeof window.pageYOffset !== 'undefined' ) {
              // Most browsers
              return window.pageYOffset;
            }

            var d = document.documentElement;
            if (d.clientHeight) {
              // IE in standards mode
              return d.scrollTop;
            }

            // IE in quirks mode
            return document.body.scrollTop;
          }

          window.onscroll = function() {
            var box = document.getElementById('box'),
                scroll = getScrollTop();

            if (scroll <= 28) {
              box.style.top = "30px";
            }
            else {
              box.style.top = (scroll + 20) + "px";
            }
          };
        });

    </script>
    <?php
}




add_action('admin_menu', 'lead_tracking_create');
function lead_tracking_create() {
    $page_title = 'CyberMark Lead Tracking';
    $menu_title = 'CyberMark Lead Tracking';
    $capability = 'edit_posts';
    $menu_slug = 'lead_tracking';
    $function = 'lead_tracking_create_display';
    $icon_url = 'dashicons-id-alt';
    $position = 2;

    add_menu_page( $page_title, $menu_title, $capability, $menu_slug, $function, $icon_url, $position );
}


function lead_tracking_create_display() {
    include 'what-converts.php';
}
add_action('admin_menu', 'cybermark_support_create');
function cybermark_support_create() {
    $page_title = 'CyberMark SMART Support';
    $menu_title = 'CyberMark SMART Support';
    $capability = 'edit_posts';
    $menu_slug = 'cybermark_support';
    $function = 'cybermark_support_create_display';
    $icon_url = 'dashicons-admin-tools';
    $position = 2;

    add_menu_page( $page_title, $menu_title, $capability, $menu_slug, $function, $icon_url, $position );
}


function cybermark_support_create_display() {
    include 'cybermark-support.php';
}

add_action('admin_menu', 'cybermark_report_create');
function cybermark_report_create() {
    $page_title = 'CyberMark Reporting';
    $menu_title = 'CyberMark Reporting';
    $capability = 'edit_posts';
    $menu_slug = 'cybermark_report';
    $function = 'cybermark_report_create_display';
    $icon_url = 'dashicons-admin-tools';
    $position = 2;

    add_menu_page( $page_title, $menu_title, $capability, $menu_slug, $function, $icon_url, $position );
}


function cybermark_report_create_display() {
    include 'cybermark-reporting.php';
}

//CyberMark Home Page Content
acf_add_local_field_group(array(
  'key' => 'group_5c7eb2e20a4f2',
  'title' => 'Home Page Content',
  'fields' => array(
    array(
      'key' => 'field_5cdb54fab4cd0',
      'label' => 'Main Slider',
      'name' => '',
      'type' => 'tab',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'placement' => 'top',
      'endpoint' => 0,
    ),
    array(
      'key' => 'field_5cdb5556b4cd1',
      'label' => 'Slider Heading',
      'name' => 'slider_heading',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5cdb556fb4cd2',
      'label' => 'Text',
      'name' => 'slider_text',
      'type' => 'text',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'default_value' => '',
      'placeholder' => '',
      'prepend' => '',
      'append' => '',
      'maxlength' => '',
    ),
    array(
      'key' => 'field_5cdaf1842c5af',
      'label' => 'Image Slider',
      'name' => 'image_slider',
      'type' => 'repeater',
      'instructions' => '',
      'required' => 0,
      'conditional_logic' => 0,
      'wrapper' => array(
        'width' => '',
        'class' => '',
        'id' => '',
      ),
      'collapsed' => '',
      'min' => 0,
      'max' => 0,
      'layout' => 'row',
      'button_label' => 'Add Image',
      'sub_fields' => array(
        array(
          'key' => 'field_5cdaf1922c5b0',
          'label' => 'Image',
          'name' => 'image',
          'type' => 'image',
          'instructions' => '',
          'required' => 0,
          'conditional_logic' => 0,
          'wrapper' => array(
            'width' => '',
            'class' => '',
            'id' => '',
          ),
          'return_format' => 'array',
          'preview_size' => 'thumbnail',
          'library' => 'all',
          'min_width' => '',
          'min_height' => '',
          'min_size' => '',
          'max_width' => '',
          'max_height' => '',
          'max_size' => '',
          'mime_types' => '',
        ),
      ),
    ),
  ),
  'location' => array(
    array(
      array(
        'param' => 'page_template',
        'operator' => '==',
        'value' => 'template-home.php',
      ),
    ),
  ),
  'menu_order' => 0,
  'position' => 'normal',
  'style' => 'default',
  'label_placement' => 'top',
  'instruction_placement' => 'label',
  'hide_on_screen' => array(
    0 => 'the_content',
    1 => 'excerpt',
    2 => 'discussion',
    3 => 'comments',
    4 => 'revisions',
    5 => 'slug',
    6 => 'author',
    7 => 'format',
    8 => 'featured_image',
    9 => 'categories',
    10 => 'tags',
    11 => 'send-trackbacks',
  ),
  'active' => true,
  'description' => '',
));