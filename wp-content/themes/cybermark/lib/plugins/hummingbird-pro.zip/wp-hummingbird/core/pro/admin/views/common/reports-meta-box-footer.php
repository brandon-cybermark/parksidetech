<?php
/**
 * Performance test reporting meta box footer.
 *
 * @package Hummingbird
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

	<div class="sui-actions-right">
		<button class="sui-button sui-button-blue">
			<?php esc_html_e( 'Update Settings', 'wphb' ); ?>
		</button>
	</div>
</form>